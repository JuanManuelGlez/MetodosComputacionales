# ##############################################################################################################################
# Autor: Juan Manuel González Ascencio
# Matricula: A00572003
# Descripcion: programa que permita convertir un expresión regular a un autómata finito determinístico. El programa deberá implementar el algoritmo: expresión regular -> autómata finito no determinístico -> autómata finito determinístico.
################################################################################################################################

